import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  TrendingUp,
  ShoppingCart,
  Calendar,
  DollarSign,
  Upload,
  Download,
  Sparkles,
  RefreshCw,
  FileSpreadsheet,
  AlertCircle,
  Coffee,
  Sliders,
  Search,
  ArrowUpDown,
  BookOpen,
  Info,
  ChevronLeft,
  ChevronRight,
  Sparkle,
  Linkedin,
  Github,
  Mail,
  Phone,
  MapPin,
  Globe,
  User
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceArea
} from "recharts";
import { SalesRow, DailySalesData, AssociationRule, AIAnalysisResponse } from "../types";
import { parseCSVData, RAW_SAMPLE_CSV } from "../data/sampleData";
import {
  computeTrendAnalysis,
  computeMarketBasketAnalysis,
  generateAnalysisSummary,
} from "../utils/analysis";

export default function Dashboard() {
  // --- STATE ---
  const [csvContent, setCsvContent] = useState<string>(RAW_SAMPLE_CSV);
  const [salesRows, setSalesRows] = useState<SalesRow[]>([]);
  const [targetProduct, setTargetProduct] = useState<string>("ARAB250gr");
  
  // MBA threshold parameters
  const [minSupport, setMinSupport] = useState<number>(0.01);
  const [minLift, setMinLift] = useState<number>(1.0);

  // Pagination for rules table
  const [currentPage, setCurrentPage] = useState<number>(1);
  const rulesPerPage = 8;
  const [rulesSearch, setRulesSearch] = useState<string>("");
  const [sortField, setSortField] = useState<string>("lift");
  const [sortAscending, setSortAscending] = useState<boolean>(false);

  // AI Advice state
  const [aiResponse, setAiResponse] = useState<AIAnalysisResponse | null>(null);
  const [loadingAI, setLoadingAI] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string>("");

  // drag and drop feedback
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // Interactive Strategic Checklist for owners
  const [checklist, setChecklist] = useState([
    { id: 1, text: "Gunakan data Moving Average 3-Hari untuk persediaan aman (Safety Stock) guna mengantisipasi fluktuasi mendadak.", done: false, category: "Logistik & Stok" },
    { id: 2, text: "Atur posisi display produk komplementer (berdasarkan Lift Score tertinggi) agar saling berdekatan (cross-merchandising).", done: true, category: "Penataan Rak" },
    { id: 3, text: "Luncurkan Paket Bundling Khusus yang menggabungkan produk utama dengan item aksesoris teratas.", done: false, category: "Promosi & Bundling" },
    { id: 4, text: "Sesuaikan jadwal shift barista / staf tambahan pada H-1 tanggal historis fluktuasi puncak penjualan.", done: false, category: "Operasional Toko" },
    { id: 5, text: "Evaluasi rasio margin keuntungan paket bundle promosi secara berkala di tiap akhir bulan.", done: false, category: "Keuangan & Evaluasi" },
  ]);

  const toggleChecklistItem = (id: number) => {
    setChecklist(prev => prev.map(item => item.id === id ? { ...item, done: !item.done } : item));
  };

  // --- PARSE INITIAL DATA ---
  useEffect(() => {
    const parsed = parseCSVData(csvContent);
    setSalesRows(parsed);
    
    // Automatically select first common item if default ARAB250gr is missing
    const uniqueProds = Array.from(new Set(parsed.map((r) => r.nama_produk)));
    const hasArab = uniqueProds.some((p) => p.toLowerCase().includes("arab250gr"));
    if (!hasArab && uniqueProds.length > 0) {
      setTargetProduct(uniqueProds[0]);
    }
  }, [csvContent]);

  // --- DERIVED METRICS ---
  const { dailySales, targetLabel, isFallback } = useMemo(() => {
    return computeTrendAnalysis(salesRows, targetProduct);
  }, [salesRows, targetProduct]);

  const associationRules = useMemo(() => {
    return computeMarketBasketAnalysis(salesRows, minSupport, minLift);
  }, [salesRows, minSupport, minLift]);

  const summary = useMemo(() => {
    return generateAnalysisSummary(salesRows, dailySales, associationRules, targetProduct);
  }, [salesRows, dailySales, associationRules, targetProduct]);

  // Unique product options for dropdown
  const productOptions = useMemo(() => {
    return Array.from(new Set(salesRows.map((r) => r.nama_produk))).sort();
  }, [salesRows]);

  // Get current active rise details
  const peakStreak = useMemo(() => {
    let maxRise = 0;
    let maxDate = "-";
    dailySales.forEach((d) => {
      if (d.Consecutive_Rise > maxRise) {
        maxRise = d.Consecutive_Rise;
        maxDate = d.formattedDate;
      }
    });
    return { maxRise, maxDate };
  }, [dailySales]);

  // --- FILE HANDLING OPERATIONS ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCsvContent(event.target.result as string);
        setCurrentPage(1);
        setAiResponse(null); // Reset AI advisor when data changes
      }
    };
    reader.readAsText(file);
  };

  const loadSampleData = () => {
    setCsvContent(RAW_SAMPLE_CSV);
    setTargetProduct("ARAB250gr");
    setCurrentPage(1);
    setAiResponse(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCsvContent(event.target.result as string);
          setCurrentPage(1);
          setAiResponse(null);
        }
      };
      reader.readAsText(file);
    }
  };

  // --- DATA EXPORT OPERATORS ---
  const downloadTrendCSV = () => {
    let content = "tgl_transaksi;total_penjualan;MA_3_hari;Is_Rising;Consecutive_Rise_Days\n";
    dailySales.forEach((d) => {
      content += `${d.formattedDate};${d.total_nilai.toFixed(0)};${d.MA_3.toFixed(0)};${d.Is_Rising};${d.Consecutive_Rise}\n`;
    });
    triggerDownload(content, `Analisis_Tren_${targetLabel.replace(/\s+/g, "_")}.csv`);
  };

  const downloadMarketBasketCSV = () => {
    let content = "Jika_Membeli(Antecedents);Maka_Membeli(Consequents);Jumlah_Invoice;Support;Confidence;Lift_Score\n";
    associationRules.forEach((r) => {
      content += `"${r.antecedents.join(", ")}";"${r.consequents.join(", ")}";${r.invoiceCount};${r.support.toFixed(4)};${r.confidence.toFixed(4)};${r.lift.toFixed(4)}\n`;
    });
    triggerDownload(content, "Market_Basket_Analysis_Rules.csv");
  };

  const triggerDownload = (text: string, filename: string) => {
    const blob = new Blob([text], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadSampleTemplateCSV = () => {
    triggerDownload(RAW_SAMPLE_CSV, "data_penjualan.csv");
  };

  // --- CONSULT GEMINI API AGENT ---
  const handleConsultAI = async () => {
    setLoadingAI(true);
    setAiError("");
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetLabel,
          summary,
          topRules: associationRules.slice(0, 5),
        }),
      });

      const data = await response.json();
      if (data.success) {
        setAiResponse(data);
      } else {
        setAiError(data.error || "Gagal mengolah wawasan strategis AI.");
      }
    } catch (err: any) {
      console.error(err);
      setAiError("Gagal menghubungi server AI Consultant. Pastikan API key Anda aktif.");
    } finally {
      setLoadingAI(false);
    }
  };

  // --- TABLE FILTERING AND PROCESSING ---
  const rulesFiltered = useMemo(() => {
    return associationRules.filter((r) => {
      const searchLower = rulesSearch.toLowerCase();
      const anteMatch = r.antecedents.some((a) => a.toLowerCase().includes(searchLower));
      const consMatch = r.consequents.some((c) => c.toLowerCase().includes(searchLower));
      return anteMatch || consMatch;
    });
  }, [associationRules, rulesSearch]);

  const rulesSorted = useMemo(() => {
    return [...rulesFiltered].sort((a: any, b: any) => {
      let valA = a[sortField];
      let valB = b[sortField];
      
      // Handle arrays
      if (Array.isArray(valA)) valA = valA.join(", ");
      if (Array.isArray(valB)) valB = valB.join(", ");

      if (valA < valB) return sortAscending ? -1 : 1;
      if (valA > valB) return sortAscending ? 1 : -1;
      return 0;
    });
  }, [rulesFiltered, sortField, sortAscending]);

  const paginatedRules = useMemo(() => {
    const startIndex = (currentPage - 1) * rulesPerPage;
    return rulesSorted.slice(startIndex, startIndex + rulesPerPage);
  }, [rulesSorted, currentPage]);

  const totalPages = Math.ceil(rulesSorted.length / rulesPerPage);

  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortAscending(!sortAscending);
    } else {
      setSortField(field);
      setSortAscending(false);
    }
  };

  // --- CHART HELPERS ---
  const chartData = useMemo(() => {
    return dailySales.map((d) => ({
      ...d,
      // Create a specific fill-metric that matches consecutive rises
      arsiranValue: d.Consecutive_Rise > 0 ? d.total_nilai * 1.15 : 0,
      isRisingWord: d.Is_Rising === 1 ? "Naik" : "Turun/Ukur",
    }));
  }, [dailySales]);

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800 flex flex-col">
      
      {/* HIGH RES EXECUTIVE COHESIVE HEADER */}
      <header className="bg-[#1F4E78] text-white px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center shrink-0 shadow-md border-b-4 border-slate-200">
        <div className="flex items-center gap-4">
          <div className="bg-white/10 p-2.5 rounded-lg border border-white/10">
            <Coffee className="w-6 h-6 text-orange-400 shrink-0" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight uppercase font-display">
              DASHBOARD STRATEGIS: TREN PENJUALAN &amp; MARKET BASKET
            </h1>
            <p className="text-xs text-slate-300 font-medium flex flex-wrap items-center gap-2 mt-1">
              <span>Portfolio Analisis Retail</span>
              <span className="text-slate-400">•</span>
              <span>Target Produk Fokus: <span className="font-semibold text-white bg-slate-800/40 px-1 rounded">{targetLabel}</span></span>
              <span className="text-slate-400">•</span>
              <span className="inline-flex items-center gap-1 bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wide border border-amber-500/30">
                <User className="w-3 h-3" /> Analis: Haris Arief Kamis
              </span>
            </p>
          </div>
        </div>

        <div className="text-right mt-3 md:mt-0 flex flex-row md:flex-col gap-2 items-center md:items-end justify-between w-full md:w-auto">
          <span className="text-[10px] font-mono font-bold bg-black/25 px-2.5 py-1 rounded-md border border-white/10 text-emerald-400 flex items-center gap-1.5 uppercase">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Analisis Berhasil
          </span>
          <span className="text-[9px] text-slate-300 font-mono tracking-widest mt-0.5 uppercase block">
            Target: {targetProduct}
          </span>
        </div>
      </header>

      {/* CORE FRAME LAYOUT */}
      <main className="flex-grow p-4 md:p-6 space-y-5">

        {/* SYSTEM INGESTION & DATA UTILITIES DRAWER - FULL WIDTH */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          
          {/* FILE DRAGZONE */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`lg:col-span-8 relative border-2 border-dashed rounded-xl p-4 transition-all duration-200 text-center flex flex-col sm:flex-row items-center justify-between gap-4 ${
              isDragging 
                ? "border-amber-500 bg-amber-50/70" 
                : "border-slate-300 bg-white hover:border-amber-400/80 shadow-xs"
            }`}
          >
            <div className="flex items-center gap-3.5 text-left">
              <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  Unggah File Penjualan Anda (Format: data_penjualan.csv)
                </h3>
                <p className="text-[11px] text-slate-400 leading-normal mt-0.5 max-w-xl">
                  Bongkar rahasia retail Anda. Drag &amp; drop file CSV disini. Sistem mendeteksi pemisah <code className="font-mono bg-slate-100 text-amber-700 px-1 rounded font-semibold text-[10px]">;</code> atau <code className="font-mono bg-slate-100 text-amber-700 px-1 rounded font-semibold text-[10px]">,</code> dengan kolom: nomor_struk, nama_produk, jumlah_terjual, total_nilai, tgl_transaksi.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <label className="inline-flex items-center justify-center cursor-pointer bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-950 font-bold font-mono tracking-wide text-[10px] uppercase px-3.5 py-2 rounded-lg transition shadow-sm">
                <span>Unggah CSV</span>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* QUICK TOGGLES & LOAD CONTROLS */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between shadow-xs gap-3">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">DATASET UTILITIES</p>
              <h4 className="text-xs font-semibold text-slate-800">Uji Coba Cepat Dataset</h4>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={loadSampleData}
                className="flex items-center justify-center gap-1.5 px-2.5 py-2 text-[10px] font-bold uppercase font-mono tracking-wider text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
                title="Reset dataset back to high-fidelity coffee shop sample"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                Reset Sampel
              </button>
              
              <button
                onClick={downloadSampleTemplateCSV}
                className="flex items-center justify-center gap-1.5 px-2.5 py-2 text-[10px] font-bold uppercase font-mono tracking-wider text-[#1F4E78] bg-[#1F4E78]/5 hover:bg-[#1F4E78]/10 rounded-lg transition"
                title="Download the clean schema CSV template"
              >
                <Download className="w-3.5 h-3.5 text-[#1F4E78]" />
                Template CSV
              </button>
            </div>
          </div>

        </div>

        {/* METRICS BRIEF CABINET */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Total Revenue */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">TOTAL NILAI PENJUALAN</p>
              <p className="text-lg md:text-xl font-bold font-mono text-slate-800">
                Rp {summary.totalRevenue.toLocaleString("id-ID")}
              </p>
            </div>
            <p className="text-[10px] text-emerald-600 font-medium mt-1.5 flex items-center gap-1.5">
              <span>↑</span> Total Akumulatif Pendapatan
            </p>
          </div>

          {/* Total Receipts */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">TOTAL TRANSAKSI (INVOICE)</p>
              <p className="text-lg md:text-xl font-bold font-mono text-slate-800">
                {summary.totalTransactions.toLocaleString("id-ID")}
              </p>
            </div>
            <p className="text-[10px] text-slate-400 mt-1.5">
              Processed via Apriori Mining
            </p>
          </div>

          {/* Streak Record - Styled exactly like Design HTML */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs border-l-4 border-orange-500 flex flex-col justify-between">
            <div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">REKOR KENAIKAN</p>
              <p className="text-lg md:text-xl font-bold text-slate-800">
                {peakStreak.maxRise} Hari Beruntun
              </p>
            </div>
            <p className="text-[10px] text-orange-600 font-semibold font-mono mt-1.5">
              🔥 Consecutive Rise ({peakStreak.maxDate})
            </p>
          </div>

          {/* Rules Count */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">ATURAN ASOSIASI (MB)</p>
              <p className="text-lg md:text-xl font-bold font-mono text-slate-800 font-mono">
                {summary.rulesCount} Aturan
              </p>
            </div>
            <p className="text-[10px] text-blue-600 font-medium mt-1.5">
              Lift Score &gt; {minLift} (Positif Kuat)
            </p>
          </div>

        </div>

        {/* CORE HIGH DENSITY DOCK GRIDS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          
          {/* MAIN GRAPH AREA - 8 COLS */}
          <section className="lg:col-span-8 flex flex-col gap-4">
            
            <div className="bg-white flex-grow rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
              
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                <div>
                  <h2 className="text-xs font-bold text-[#1F4E78] uppercase flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-orange-500 shrink-0" />
                    Visualisasi Fluktuasi Harian (MA 3-Hari)
                    {isFallback && (
                      <span className="text-[8px] tracking-widest px-1 bg-amber-100 text-amber-800 rounded font-mono uppercase">
                        Fallback
                      </span>
                    )}
                  </h2>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Perbandingan harian nilai penjualan ({targetLabel}) dengan tren filter Moving Average 3-Hari.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={downloadTrendCSV}
                    className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#1F4E78] bg-[#1F4E78]/5 hover:bg-[#1F4E78]/10 rounded-lg transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Ekspor CSV
                  </button>
                </div>
              </div>

              {/* RECHARTS PLOT */}
              <div className="h-[280px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart
                    data={chartData}
                    margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
                  >
                    <defs>
                      <linearGradient id="streakFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0.0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis 
                      dataKey="formattedDate" 
                      tick={{ fontSize: 9, fill: "#64748B", fontFamily: "monospace" }}
                      tickLine={false}
                      axisLine={{ stroke: "#CBD5E1" }}
                    />
                    <YAxis 
                      tickFormatter={(val) => `Rp ${val.toLocaleString("id-ID", { notation: "compact" })}`} 
                      tick={{ fontSize: 9, fill: "#64748B" }}
                      tickLine={false}
                      axisLine={{ stroke: "#CBD5E1" }}
                    />
                    <Tooltip 
                      formatter={(value: any, name: any) => {
                        if (name === "Penjualan Aktual Harian" || name === "Tren Moving Average (MA 3-Hari)") {
                          return [`Rp ${value.toLocaleString("id-ID")}`, name];
                        }
                        if (name === "Kenaikan Beruntun") {
                          return [`${value} Hari`, "Kenaikan Beruntun"];
                        }
                        return [value, name];
                      }}
                      contentStyle={{ backgroundColor: "#FFFFFF", borderRadius: "8px", border: "1px solid #E2E8F0", fontSize: "11px" }}
                    />
                    <Legend 
                      verticalAlign="top" 
                      height={28} 
                      iconType="circle"
                      wrapperStyle={{ fontSize: "10px", color: "#475569", fontWeight: "bold", textTransform: "uppercase" }}
                    />

                    {/* Area fill for consecutive rises */}
                    <Area 
                      type="monotone" 
                      dataKey="Consecutive_Rise" 
                      stroke="none" 
                      fill="url(#streakFill)"
                      name="Kenaikan Beruntun"
                    />

                    {/* Actual grey dashed line */}
                    <Line 
                      type="monotone" 
                      dataKey="total_nilai" 
                      stroke="#BDC3C7" 
                      strokeWidth={1.5}
                      strokeDasharray="4 4"
                      dot={{ r: 3, strokeWidth: 1 }}
                      activeDot={{ r: 5 }}
                      name="Penjualan Aktual Harian"
                    />

                    {/* Prominent Orange MA3 Line */}
                    <Line 
                      type="monotone" 
                      dataKey="MA_3" 
                      stroke="#E67E22" 
                      strokeWidth={3}
                      dot={false}
                      name="Tren Moving Average (MA 3-Hari)"
                    />
                  </ComposedChart>
                </ResponsiveContainer>

                {/* Nice Floating Insight absolute block (styled matching prompt) */}
                <div className="absolute bottom-3 left-3 bg-white/95 border border-orange-500 px-3 py-1.5 rounded shadow-sm z-10 text-left">
                  <p className="text-[9px] font-bold text-orange-600 uppercase tracking-widest">Wawasan Grafik:</p>
                  <p className="text-[10px] leading-snug text-slate-700 font-semibold font-mono">
                    🔥 Rekor: {peakStreak.maxRise} Hari Beruntun<br/>
                    (Puncak: {peakStreak.maxDate})
                  </p>
                </div>
              </div>

              {/* HIGH DENSITY LEGEND FOOTER INFO */}
              <div className="flex flex-wrap text-[9px] gap-x-4 gap-y-1.5 text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-200 mt-4 leading-normal">
                <span className="flex items-center gap-1 text-slate-600">
                  <span className="w-3 h-0.5 bg-[#BDC3C7] border-dashed inline-block"></span>
                  Latar Belakang: Fluktuasi penjualan aktual harian
                </span>
                <span className="flex items-center gap-1 text-slate-600">
                  <span className="w-3 h-0.5 bg-[#E67E22] inline-block"></span>
                  Indikator Utama: Tren data Moving Average (MA 3-Hari)
                </span>
                <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                  <span className="w-3 h-2.5 bg-emerald-100 border border-emerald-300 rounded inline-block"></span>
                  Arsiran Hijau: Periode penguatan tren beruntun terdeteksi
                </span>
              </div>

            </div>
          </section>

          {/* SIDE CONFIG CONTROL PANEL - 4 COLS */}
          <aside className="lg:col-span-4 flex flex-col gap-4">
            
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
              
              <div className="border-b border-slate-100 pb-2">
                <h3 className="text-xs font-bold text-[#1F4E78] uppercase tracking-wide">
                  Parameter &amp; Kendali
                </h3>
                <p className="text-[10px] text-slate-400">
                  Saring target visualisasi tren &amp; parameter mining.
                </p>
              </div>

              {/* Target Product Dropdown menu */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Produk Fokus Evaluasi
                </label>
                <div className="relative">
                  <select
                    value={targetProduct}
                    onChange={(e) => setTargetProduct(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs py-1.5 px-2.5 focus:border-amber-400 focus:bg-white rounded-lg outline-hidden appearance-none pr-8 cursor-pointer font-medium"
                  >
                    {productOptions.map((prod) => (
                      <option key={prod} value={prod}>
                        {prod}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                    <Coffee className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              <hr className="border-slate-100" />

              {/* Support slider controls */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Kriteria Rules Apriori
                </span>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-600">Min Support (Popularitas)</span>
                    <span className="font-mono font-bold text-slate-800 bg-slate-100 px-1 rounded">
                      {(minSupport * 100).toFixed(1)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.005"
                    max="0.08"
                    step="0.005"
                    value={minSupport}
                    onChange={(e) => {
                      setMinSupport(parseFloat(e.target.value));
                      setCurrentPage(1);
                    }}
                    className="w-full accent-amber-500 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Lift score parameter */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-600">Min Lift Score (Kekuatan Hubungan)</span>
                    <span className="font-mono font-bold text-slate-800 bg-slate-100 px-1 rounded font-mono">
                      {minLift.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="2.5"
                    step="0.1"
                    value={minLift}
                    onChange={(e) => {
                      setMinLift(parseFloat(e.target.value));
                      setCurrentPage(1);
                    }}
                    className="w-full accent-amber-500 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
                  />
                </div>
              </div>

              <div className="bg-amber-50/50 p-3 rounded-lg border border-amber-200 text-[10px] leading-relaxed text-amber-800">
                <p className="font-semibold text-amber-900 uppercase tracking-wider">Metode Data Mining:</p>
                <p className="mt-0.5 text-amber-800 font-sans">
                  Sistem mengekstrak frequent itemsets melintasi struk belanja harian secara real-time untuk membangun association rules belanja.
                </p>
              </div>

            </div>

            {/* SYSTEM STATIC EXCEL OUTPUT LABELS CARD */}
            <div className="bg-[#1F4E78] p-4 rounded-xl text-white shadow-inner flex flex-col justify-between space-y-3">
              <div>
                <dt className="text-[10px] font-bold uppercase tracking-widest text-orange-400 mb-1">
                  System Export Layout Outputs
                </dt>
                <p className="text-[11px] text-slate-300 leading-normal">
                  File laporan formal retail dengan penataan gaya baris eksekutif yang didownload siap diunggah ke portfolio Anda:
                </p>
              </div>

              <div className="space-y-2 font-mono text-[11px]">
                <div className="flex justify-between items-center p-2 bg-white/10 rounded border border-white/5">
                  <span className="truncate">Portfolio_Analisis_Retail_Dashboard.xlsx</span>
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider shrink-0 ml-1">Excel</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-white/10 rounded border border-white/5">
                  <span>dashboard_tren_penjualan.png</span>
                  <span className="text-[9px] bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider shrink-0 ml-1">PNG</span>
                </div>
              </div>
            </div>

          </aside>
        </div>

        {/* DECISION MAKING & STRATEGIC INSIGHTS PORTFOLIO SECTION */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <span className="px-2 py-0.5 bg-slate-100 text-slate-800 border border-slate-200 text-[10px] font-mono rounded-md font-bold uppercase tracking-wider">
                Dokumen Manajemen Operasional
              </span>
              <h2 className="text-sm font-bold text-[#1F4E78] uppercase mt-1 flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-orange-500" />
                Formulasi Keputusan Strategis &amp; Rekomendasi Bisnis Masa Depan
              </h2>
              <p className="text-[10px] text-slate-400 mt-0.5 font-sans">
                Rasional pengambilan kebijakan retail berbasis pembuktian data tren Moving Average dan kaidah Asosiasi Market Basket.
              </p>
            </div>
            
            {/* Visual Progress Bar for Interactive Checklist */}
            <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg text-[10px]">
              <span className="font-bold text-slate-600 font-mono">Progress Implementasi:</span>
              <div className="w-24 bg-slate-200 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${(checklist.filter(c => c.done).length / checklist.length) * 105}%` }}
                />
              </div>
              <span className="font-bold font-mono text-emerald-600">
                {checklist.filter(c => c.done).length}/{checklist.length} ({((checklist.filter(c => c.done).length / checklist.length) * 100).toFixed(0)}%)
              </span>
            </div>
          </div>

          {/* Interactive Bento Guide Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Card 1: Alinyemen Stok & Supply Chain */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl flex flex-col justify-between hover:border-amber-400 transition duration-150">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="p-1 px-1.5 bg-[#1F4E78]/10 text-[#1F4E78] font-mono text-[9px] font-bold rounded">
                    Langkah 1
                  </span>
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-700">Rantai Pasokan Pintar</h4>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-600">
                  Gunakan garis <strong>Moving Average 3-Hari</strong> sebagai basis penentuan persediaan aman (Safety Stock) bahan dasar <span className="font-mono text-xs text-orange-700 font-bold">{targetLabel}</span> untuk meredam lonjakan mendadak serta meminimalisir dana mati di gudang (dead stock) saat tren mendingin.
                </p>
              </div>
              <p className="text-[9px] text-[#1F4E78] font-bold mt-3 border-t border-slate-200/80 pt-2 font-mono">
                → Mencegah Overstock &amp; OOS
              </p>
            </div>

            {/* Card 2: Shelf-Placement & Visual Merchandising */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl flex flex-col justify-between hover:border-amber-400 transition duration-150">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="p-1 px-1.5 bg-sky-100 text-sky-800 font-mono text-[9px] font-bold rounded">
                    Langkah 2
                  </span>
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-700">Penataan Display Rak</h4>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-600">
                  Tempatkan produk dengan <strong>Lift Score tertajam</strong> berdekatan secara fisik di toko fisik atau posisikan sebagai saran "Kerap Dibeli Bersama" di kanal digital. Menaruh gula aren atau pelengkap kopi berdekatan mendorong peningkatan keranjang belanja pembeli.
                </p>
              </div>
              <p className="text-[9px] text-[#1F4E78] font-bold mt-3 border-t border-slate-200/80 pt-2 font-mono">
                → Taktik Cross-Merchandising
              </p>
            </div>

            {/* Card 3: Skema Pricing & Bundling Hebat */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl flex flex-col justify-between hover:border-amber-400 transition duration-150">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="p-1 px-1.5 bg-emerald-100 text-emerald-800 font-mono text-[9px] font-bold rounded">
                    Langkah 3
                  </span>
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-700">Skema Paket Promosi</h4>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-600">
                  Rumuskan paket diskon kombinasi menggunakan item dengan nilai <strong>Confidence tinggi</strong>. Paket bundle dengan margin optimal diyakini mampu mendongkrak penjualan silang barang sekunder yang semula kurang populer di transaksi.
                </p>
              </div>
              <p className="text-[9px] text-[#1F4E78] font-bold mt-3 border-t border-slate-200/80 pt-2 font-mono">
                → Bundling Berbasis Pembuktian
              </p>
            </div>

            {/* Card 4: Mitigasi Operasional & Penjadwalan */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl flex flex-col justify-between hover:border-amber-400 transition duration-150">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="p-1 px-1.5 bg-amber-100 text-amber-800 font-mono text-[9px] font-bold rounded">
                    Langkah 4
                  </span>
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-700">Penjadwalan Shift &amp; Staf</h4>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-600">
                  Antisipasi lonjakan hari puncak yang dikonfirmasi oleh <strong>rekor kenaikan beruntun harian</strong>. Tambahkan penugasan tim barista atau kasir pada H-1 pola siklus puncak guna menjaga tingkat kecepatan layanan transaksi retail.
                </p>
              </div>
              <p className="text-[9px] text-[#1F4E78] font-bold mt-3 border-t border-slate-200/80 pt-2 font-mono">
                → Standarisasi Respons Operasi
              </p>
            </div>

          </div>

          {/* Interactive Checkbox List for Dashboard Interactive Utilization */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 font-sans">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-3 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
              Aksi Operasional yang Harus Dijalankan (Checklist Owner)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {checklist.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => toggleChecklistItem(item.id)}
                  className={`p-3 rounded-lg border flex items-start gap-2.5 transition duration-100 cursor-pointer select-none ${
                    item.done 
                      ? "bg-emerald-50/50 border-emerald-300 text-emerald-950" 
                      : "bg-white border-slate-200 hover:border-slate-300 text-slate-800"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={item.done}
                    onChange={() => {}} // handled by click parent for touch target safety
                    className="mt-0.5 rounded border-slate-300 accent-emerald-500 pointer-events-none shrink-0"
                  />
                  <div className="space-y-0.5">
                    <span className="text-[9px] uppercase tracking-wider font-bold block opacity-60 text-emerald-900">
                      {item.category}
                    </span>
                    <p className="text-[10.5px] leading-relaxed">
                      {item.text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-[9.5px] text-slate-400 mt-3 italic text-right font-sans">
              *Klik pada kartu checklist untuk menandai tugas operasional toko Anda yang telah berhasil diselesaikan.
            </p>
          </div>
        </div>

        {/* DETAILED APRIORI RULES DATA TABLE */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          
          <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50">
            <div>
              <h3 className="text-xs font-bold text-[#1F4E78] uppercase flex items-center gap-1.5">
                <ShoppingCart className="w-4 h-4 text-emerald-500 shrink-0" />
                Matriks Aturan Asosiasi (Market Basket Analysis)
                <span className="text-[10px] tracking-wider px-2 py-0.5 bg-sky-100 text-sky-800 rounded font-mono font-bold uppercase">
                  Metrik: Lift Score
                </span>
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Membongkar korelasi cross-selling barang berdasarkan pola belanja riil di struk belanja aktif.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
              {/* Rules Search bar */}
              <div className="relative shrink-0">
                <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400">
                  <Search className="w-3.5 h-3.5" />
                </span>
                <input
                  type="text"
                  placeholder="Saring nama barang..."
                  value={rulesSearch}
                  onChange={(e) => {
                    setRulesSearch(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full sm:w-48 pl-8 pr-2.5 py-1 bg-white border border-slate-300 text-xs rounded-lg focus:border-amber-400 outline-hidden font-sans text-slate-700"
                />
              </div>

              {/* MBA Rules export download button */}
              <button
                onClick={downloadMarketBasketCSV}
                className="flex items-center justify-center gap-1 px-3 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg shrink-0 transition"
                title="Download association rules results as a csv file"
              >
                <Download className="w-3.5 h-3.5" />
                Ekspor Aturan
              </button>
            </div>
          </div>

          {/* TABLE DISPLAY */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px] font-sans">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-[10px] uppercase tracking-wider text-slate-600 font-bold font-mono">
                  <th className="p-3 text-left">Jika Membeli (Antecedents)</th>
                  <th className="p-3 text-left">Maka Membeli (Consequents)</th>
                  <th 
                    className="p-3 text-center cursor-pointer hover:bg-slate-200/50 transition"
                    onClick={() => toggleSort("invoiceCount")}
                  >
                    <span className="flex items-center justify-center gap-1">
                      Jumlah Invoice
                      <ArrowUpDown className="w-3 h-3 text-slate-400 shrink-0" />
                    </span>
                  </th>
                  <th 
                    className="p-3 text-center cursor-pointer hover:bg-slate-200/50 transition"
                    onClick={() => toggleSort("support")}
                  >
                    <span className="flex items-center justify-center gap-1">
                      Support
                      <ArrowUpDown className="w-3 h-3 text-slate-400 shrink-0" />
                    </span>
                  </th>
                  <th 
                    className="p-3 text-center cursor-pointer hover:bg-slate-200/50 transition"
                    onClick={() => toggleSort("confidence")}
                  >
                    <span className="flex items-center justify-center gap-1">
                      Confidence (Kepastian)
                      <ArrowUpDown className="w-3 h-3 text-slate-400 shrink-0" />
                    </span>
                  </th>
                  <th 
                    className="p-3 text-center cursor-pointer hover:bg-slate-200/50 transition"
                    onClick={() => toggleSort("lift")}
                  >
                    <span className="flex items-center justify-center gap-1">
                      Lift Score
                      <ArrowUpDown className="w-3 h-3 text-slate-400 shrink-0" />
                    </span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {paginatedRules.length > 0 ? (
                  paginatedRules.map((r, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition duration-150">
                      <td className="p-3">
                        {r.antecedents.map((item) => (
                          <span key={item} className="inline-block bg-blue-50 border border-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold mr-1 mb-1 font-mono">
                            {item}
                          </span>
                        ))}
                      </td>
                      <td className="p-3">
                        {r.consequents.map((item) => (
                          <span key={item} className="inline-block bg-teal-50 border border-teal-100 text-teal-800 px-1.5 py-0.5 rounded font-bold mr-1 mb-1 font-mono">
                            {item}
                          </span>
                        ))}
                      </td>
                      <td className="p-3 text-center font-mono font-medium text-slate-900">
                        {r.invoiceCount} Struk
                      </td>
                      <td className="p-3 text-center font-mono">
                        {(r.support * 100).toFixed(2)}%
                      </td>
                      <td className="p-3">
                        <div className="flex items-center justify-center gap-2">
                          <span className="font-mono">{(r.confidence * 100).toFixed(1)}%</span>
                          <div className="w-10 bg-slate-100 h-1 rounded-full overflow-hidden hidden sm:block">
                            <div 
                              className="bg-amber-400 h-full rounded-full" 
                              style={{ width: `${r.confidence * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full font-semibold font-mono text-[10px] bg-amber-100 text-orange-700 border border-amber-300">
                          {r.lift.toFixed(3)}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="text-center p-8 text-slate-400">
                      <div className="flex flex-col items-center gap-1.5">
                        <AlertCircle className="w-5 h-5 text-slate-300 shrink-0" />
                        <span className="text-[11px]">Tidak ditemukan korelasi aturan belanja yang memenuhi kriteria di dataset aktif Anda.</span>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Dynamic Table Pagination */}
          {rulesSorted.length > rulesPerPage && (
            <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs">
              <span className="text-slate-500 font-medium">
                Menampilkan {Math.min(rulesSorted.length, (currentPage - 1) * rulesPerPage + 1)}-
                {Math.min(rulesSorted.length, currentPage * rulesPerPage)} dari {rulesSorted.length} Aturan Asosiasi
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                  className="p-1 px-2.5 bg-white border border-slate-200 hover:bg-slate-50 active:bg-slate-100 disabled:opacity-50 text-slate-600 rounded-lg transition"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <span className="text-slate-700 px-2 font-mono font-bold">
                  Hal {currentPage} / {totalPages}
                </span>
                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                  className="p-1 px-2.5 bg-white border border-slate-200 hover:bg-slate-50 active:bg-slate-100 disabled:opacity-50 text-slate-600 rounded-lg transition"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* CONSULT GEMINI AI CONSULTANT COMPONENT - EXECUTIVELY POLISHED WITH DEEP BLUE & NAVY */}
        <div className="bg-slate-900 ring-2 ring-slate-800 p-6 md:p-8 rounded-2xl text-white shadow-xl relative overflow-hidden transition duration-500 mt-6">
          <div className="absolute right-0 top-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute left-1/3 bottom-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative flex flex-col lg:flex-row justify-between items-start gap-8 z-10">
            <div className="space-y-3.5 max-w-3xl">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-1 bg-amber-500/20 text-amber-300 font-mono text-[10px] rounded-md font-bold uppercase tracking-widest flex items-center gap-1 border border-amber-500/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  Senior Retail Strategic Advisor
                </span>
              </div>
              
              <h2 className="text-xl font-display font-medium tracking-tight">
                Konsultasikan Strategi Operasional &amp; Bundling Toko Anda
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed font-sans">
                Kirim data rekor penjualan {targetLabel} ({peakStreak.maxRise} hari berturut-turut) serta {summary.rulesCount} aturan keranjang belanja yang terdeteksi untuk merangkai program marketing bundling kopi, penataan etalase rak belanja, dan prediksi logistik.
              </p>
            </div>

            <button
              onClick={handleConsultAI}
              disabled={loadingAI}
              className="w-full lg:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 font-bold font-mono tracking-wide text-xs uppercase rounded-xl transition shadow-lg shrink-0 flex items-center justify-center gap-2 disabled:bg-slate-800 disabled:text-slate-500 cursor-pointer"
            >
              {loadingAI ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Mengevaluasi Pola Toko...
                </>
              ) : (
                <>
                  <Sparkle className="w-4 h-4 fill-current text-slate-950 shrink-0" />
                  Formulasikan Promosi &amp; Insight AI
                </>
              )}
            </button>
          </div>

          {/* AI Error Alert */}
          {aiError && (
            <div className="mt-5 p-4 bg-red-950/40 border border-red-500/30 text-red-100 rounded-xl flex items-start gap-2.5 text-xs z-10 relative">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-red-300 uppercase tracking-wider">Kegagalan Analisis AI Advisor</p>
                <p className="mt-0.5 text-red-200 font-mono text-[11px]">{aiError}</p>
              </div>
            </div>
          )}

          {/* AI Response Block */}
          {aiResponse && (
            <div className="mt-6 pt-6 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn relative z-10">
              
              {/* Executive Summary */}
              <div className="bg-slate-800/40 p-4.5 rounded-xl border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-1.5 text-amber-400 text-[11px] font-bold uppercase tracking-wider font-mono">
                  <BookOpen className="w-3.5 h-3.5" />
                  Tinjauan Eksekutif
                </div>
                <p className="text-slate-100 text-xs leading-relaxed font-sans whitespace-pre-line">
                  {aiResponse.executiveSummary}
                </p>
              </div>

              {/* Strategic Fluctuation Advice */}
              <div className="bg-slate-800/40 p-4.5 rounded-xl border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-1.5 text-sky-400 text-[11px] font-bold uppercase tracking-wider font-mono">
                  <TrendingUp className="w-3.5 h-3.5" />
                  Navigasi Logistik &amp; Stok
                </div>
                <p className="text-slate-100 text-xs leading-relaxed font-sans whitespace-pre-line">
                  {aiResponse.strategicAdvice}
                </p>
              </div>

              {/* Bundling Promotion Plan */}
              <div className="bg-slate-800/40 p-4.5 rounded-xl border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-bold uppercase tracking-wider font-mono">
                  <ShoppingCart className="w-3.5 h-3.5" />
                  Rekomendasi Bundling Kreatif
                </div>
                <p className="text-slate-100 text-xs leading-relaxed font-sans whitespace-pre-line">
                  {aiResponse.bundleIdeas}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* DATA ANALYST PROFESSIONAL PROFILE CARD (HARIS ARIEF KAMIS) */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6 mt-6">
          <div className="border-b border-slate-200 pb-4">
            <span className="px-2 py-0.5 bg-slate-100 text-[#1F4E78] border border-slate-200 text-[10px] font-mono rounded-md font-bold uppercase tracking-wider">
              Analis Utama &amp; Pembuat Portfolio
            </span>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-2">
              <div>
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  Haris Arief Kamis
                </h2>
                <p className="text-xs text-[#1F4E78] font-semibold uppercase tracking-wider font-mono flex items-center gap-1.5 mt-0.5">
                  <TrendingUp className="w-3.5 h-3.5 text-[#1F4E78]" />
                  Data Enthusiast
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <a
                  href="https://bit.ly/WebsitePortofolioDataAnalyst"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold font-mono text-[10px] uppercase rounded-lg transition shadow-sm cursor-pointer"
                >
                  <Globe className="w-3.5 h-3.5" />
                  Website Portofolio
                </a>
                <a
                  href="https://linkedin.com/in/harisariefkamis"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#0A66C2] hover:bg-[#004182] active:scale-95 text-white font-bold font-mono text-[10px] uppercase rounded-lg transition shadow-sm cursor-pointer"
                >
                  <Linkedin className="w-3.5 h-3.5" />
                  connect linkedin
                </a>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Box 1: Kontak Langsung */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl space-y-3">
              <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-[#1F4E78]" />
                HUBUNGI SAYA
              </h4>
              <div className="space-y-1.5">
                <a 
                  href="tel:+6285282436796" 
                  className="block text-xs font-bold text-slate-800 hover:text-orange-600 transition"
                >
                  +62 852-8243-6796
                </a>
                <a 
                  href="mailto:harisariefkamis16@gmail.com" 
                  className="block text-xs font-mono text-slate-600 hover:text-orange-600 transition truncate"
                >
                  harisariefkamis16@gmail.com
                </a>
              </div>
            </div>

            {/* Box 2: Domisili & Wilayah */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl space-y-3">
              <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-red-500" />
                ALAMAT
              </h4>
              <div className="space-y-0.5">
                <p className="text-xs font-bold text-slate-800">
                  Bogor Timur, Kota Bogor
                </p>
                <p className="text-[11px] font-mono text-slate-500">
                  Jawa Barat, Indonesia - 16144
                </p>
              </div>
            </div>

            {/* Box 3: Akun GitHub & Kode Sumber */}
            <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl space-y-3">
              <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Github className="w-3.5 h-3.5 text-slate-900" />
                GITHUB
              </h4>
              <div className="space-y-1">
                <a 
                  href="https://github.com/harrisariefkamis"
                  target="_blank"
                  referrerPolicy="no-referrer"
                  rel="noopener noreferrer"
                  className="text-xs font-mono font-bold text-slate-800 hover:text-orange-600 transition flex items-center gap-1 truncate"
                >
                  github.com/harrisariefkamis
                </a>
                <span className="text-[10px] text-slate-400 block font-sans">
                  Suka dengan analisis retail ini? Jelajahi repositori kode di atas.
                </span>
              </div>
            </div>
          </div>
        </div>

      </main>

      {/* FOOTER STATS COMPLIANCE */}
      <footer className="bg-white border-t border-slate-200 px-6 py-4 flex justify-center items-center text-[10px] text-slate-500 shrink-0 mt-8">
        <div className="font-bold tracking-wider uppercase font-sans text-slate-700">
          Portofolio Haris Arief Kamis 2026
        </div>
      </footer>

    </div>
  );
}
