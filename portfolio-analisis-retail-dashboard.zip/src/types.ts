export interface SalesRow {
  nomor_struk: string;
  nama_produk: string;
  jumlah_terjual: number;
  total_nilai: number;
  tgl_transaksi: string;
}

export interface DailySalesData {
  Tanggal: string; // ISO format string YYYY-MM-DD
  formattedDate: string; // Formatting for display, e.g., DD-MM-YYYY
  total_nilai: number;
  MA_3: number;
  Is_Rising: number;
  Consecutive_Rise: number;
}

export interface AssociationRule {
  antecedents: string[];
  consequents: string[];
  invoiceCount: number;
  support: number;
  confidence: number;
  lift: number;
}

export interface AnalysisSummary {
  rekorKenaikan: number;
  rekorTanggal: string;
  targetProduct: string;
  totalRevenue: number;
  totalTransactions: number;
  uniqueProducts: string[];
  rulesCount: number;
}

export interface AIAnalysisRequest {
  targetLabel: string;
  summary: AnalysisSummary;
  topRules: AssociationRule[];
}

export interface AIAnalysisResponse {
  executiveSummary: string;
  strategicAdvice: string;
  bundleIdeas: string;
  success: boolean;
  error?: string;
}
