import { SalesRow } from "../types";

// High-fidelity preloaded Indonesian coffee shop dataset in raw CSV string format so users can inspect/download it.
export const RAW_SAMPLE_CSV = `nomor_struk;nama_produk;jumlah_terjual;total_nilai;tgl_transaksi
TX-1001;ARAB250gr;2;130000;01-05-2026
TX-1001;PAPER_FILTER;1;35000;01-05-2026
TX-1002;ROB250gr;1;55000;02-05-2026
TX-1002;GULA_AREN;2;30000;02-05-2026
TX-1003;ARAB250gr;1;65000;02-05-2026
TX-1003;PAPER_FILTER;1;35000;02-05-2026
TX-1004;MILK_1L;2;48000;03-05-2026
TX-1004;SYRUP_VANILLA;1;45000;03-05-2026
TX-1005;ARAB250gr;1;65000;03-05-2026
TX-1005;PAPER_FILTER;1;35000;03-05-2026
TX-1005;MILK_1L;1;24000;03-05-2026
TX-1006;ROB250gr;2;11000;04-05-2026
TX-1006;GULA_AREN;1;15000;04-05-2026
TX-1007;ARAB250gr;1;65000;05-05-2026
TX-1007;PAPER_FILTER;1;35000;05-05-2026
TX-1008;MILK_1L;1;24000;05-05-2026
TX-1008;SYRUP_VANILLA;1;45000;05-05-2026
TX-1009;ARAB250gr;2;130000;06-05-2026
TX-1009;PAPER_FILTER;1;35000;06-05-2026
TX-1010;ROB250gr;1;55000;06-05-2026
TX-1010;GULA_AREN;2;30000;06-05-2026
TX-1011;ARAB250gr;1;65000;07-05-2026
TX-1011;PAPER_FILTER;1;35000;07-05-2026
TX-1012;CANGKIR;2;80000;07-05-2026
TX-1013;ROB250gr;1;55000;08-05-2026
TX-1013;GULA_AREN;1;15000;08-05-2026
TX-1014;ARAB250gr;1;65000;09-05-2026
TX-1015;MILK_1L;2;48000;09-05-2026
TX-1015;SYRUP_VANILLA;1;45000;09-05-2026
TX-1016;ARAB250gr;1;65000;10-05-2026
TX-1016;PAPER_FILTER;1;35000;10-05-2026
TX-1017;ROB250gr;2;110000;10-05-2026
TX-1017;GULA_AREN;2;30000;10-05-2026
TX-1018;ARAB250gr;2;130000;11-05-2026
TX-1018;PAPER_FILTER;2;70000;11-05-2026
TX-1019;MILK_1L;1;24000;12-05-2026
TX-1019;SYRUP_VANILLA;2;90000;12-05-2026
TX-1020;ARAB250gr;1;65000;13-05-2026
TX-1020;PAPER_FILTER;1;35000;13-05-2026
TX-1021;ROB250gr;1;55000;14-05-2026
TX-1021;GULA_AREN;1;15000;14-05-2026
TX-1022;ARAB250gr;1;65000;15-05-2026
TX-1022;PAPER_FILTER;1;35000;15-05-2026
TX-1023;MILK_1L;2;48000;16-05-2026
TX-1023;SYRUP_VANILLA;1;45000;16-05-2026
TX-1024;ARAB250gr;2;130000;17-05-2026
TX-1024;PAPER_FILTER;1;35000;17-05-2026
TX-1025;ROB250gr;1;55000;18-05-2026
TX-1025;GULA_AREN;2;30000;18-05-2026
TX-1026;ARAB250gr;1;65000;19-05-2026
TX-1026;PAPER_FILTER;1;35000;19-05-2026
TX-1027;MILK_1L;1;24000;20-05-2026
TX-1027;SYRUP_VANILLA;1;45000;20-05-2026
TX-1028;ARAB250gr;1;65000;21-05-2026
TX-1028;PAPER_FILTER;1;35000;21-05-2026
TX-1029;ROB250gr;1;55000;22-05-2026
TX-1029;GULA_AREN;1;15000;22-05-2026
TX-1030;ARAB250gr;1;65000;23-05-2026
TX-1030;PAPER_FILTER;1;35000;23-05-2026
TX-1031;MILK_1L;1;24000;24-05-2026
TX-1031;SYRUP_VANILLA;1;45000;24-05-2026
TX-1032;ARAB250gr;2;130000;25-05-2026
TX-1032;PAPER_FILTER;1;35000;25-05-2026
TX-1033;ROB250gr;2;110000;26-05-2026
TX-1033;GULA_AREN;2;30000;26-05-2026
TX-1034;ARAB250gr;1;65000;27-05-2026
TX-1034;PAPER_FILTER;1;35000;27-05-2026
TX-1035;MILK_1L;2;48000;28-05-2026
TX-1035;SYRUP_VANILLA;2;90000;28-05-2026
TX-1036;ARAB250gr;1;65000;29-05-2026
TX-1036;PAPER_FILTER;1;35000;29-05-2026
TX-1037;ROB250gr;1;55000;30-05-2026
TX-1037;GULA_AREN;1;15000;30-05-2026
TX-1038;ARAB250gr;1;65000;30-05-2026
TX-1038;PAPER_FILTER;1;35000;30-05-2026
TX-1039;CANGKIR;1;40000;30-05-2026`;

/**
 * Universal CSV Parser that detects separators (, or ;) and processes rows cleanly
 */
export function parseCSVData(csvContent: string): SalesRow[] {
  const result: SalesRow[] = [];
  const lines = csvContent.split(/\r?\n/);
  if (lines.length < 2) return [];

  // Determine separator (comma or semicolon)
  const header = lines[0];
  const sep = header.includes(";") ? ";" : ",";
  const keys = header.split(sep).map((k) => k.trim());

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Handle quotes around values optionally
    let values: string[] = [];
    let current = "";
    let insideQuotes = false;

    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === sep && !insideQuotes) {
        values.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    values.push(current.trim());

    if (values.length < keys.length) continue;

    const rowObj: any = {};
    keys.forEach((key, idx) => {
      let val = values[idx] || "";
      // Remove surrounding quotes
      if (val.startsWith('"') && val.endsWith('"')) {
        val = val.substring(1, val.length - 1).trim();
      }
      rowObj[key] = val;
    });

    // Validations & transformations
    const jumlah_terjual = parseInt(rowObj.jumlah_terjual, 10);
    const total_nilai = parseFloat(rowObj.total_nilai);

    if (
      rowObj.nomor_struk &&
      rowObj.nama_produk &&
      !isNaN(jumlah_terjual) &&
      !isNaN(total_nilai) &&
      rowObj.tgl_transaksi
    ) {
      result.push({
        nomor_struk: rowObj.nomor_struk,
        nama_produk: rowObj.nama_produk,
        jumlah_terjual,
        total_nilai,
        tgl_transaksi: rowObj.tgl_transaksi,
      });
    }
  }

  return result;
}

/**
 * Normalizes Date from DD-MM-YYYY (Indonesian format) into an ISO YYYY-MM-DD
 */
export function parseIndoDate(dateStr: string): Date | null {
  const parts = dateStr.split("-");
  if (parts.length === 3) {
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // 0-indexed month
    const year = parseInt(parts[2], 10);
    if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
      return new Date(year, month, day);
    }
  }
  
  // Fallback
  const parsed = new Date(dateStr);
  return isNaN(parsed.getTime()) ? null : parsed;
}
