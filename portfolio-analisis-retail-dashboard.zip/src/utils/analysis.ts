import { SalesRow, DailySalesData, AssociationRule, AnalysisSummary } from "../types";
import { parseIndoDate } from "../data/sampleData";

/**
 * Computes Trend Analysis (Steps 1 to 5)
 */
export function computeTrendAnalysis(
  allRows: SalesRow[],
  targetProduct: string
): { dailySales: DailySalesData[]; targetLabel: string; isFallback: boolean } {
  // 1. Filter rows by targetProduct
  let targetLabel = targetProduct;
  let isFallback = false;
  let filtered = allRows.filter((row) =>
    row.nama_produk.toLowerCase().includes(targetProduct.toLowerCase())
  );

  if (filtered.length === 0) {
    filtered = [...allRows];
    targetLabel = "Semua Produk (Fallback)";
    isFallback = true;
  }

  // 1b. Group by target date & aggregate (Sum of total_nilai)
  // Map date formatting
  const dateMap: { [key: string]: { dateStr: string; displayStr: string; sum: number } } = {};

  filtered.forEach((row) => {
    const rawDate = parseIndoDate(row.tgl_transaksi);
    if (!rawDate) return;
    
    // Normalize to YYYY-MM-DD
    const isoDateStr = rawDate.toISOString().split("T")[0];
    
    if (!dateMap[isoDateStr]) {
      dateMap[isoDateStr] = {
        dateStr: isoDateStr,
        displayStr: row.tgl_transaksi,
        sum: 0,
      };
    }
    dateMap[isoDateStr].sum += row.total_nilai;
  });

  // Sort dates chronologically
  const sortedDates = Object.keys(dateMap).sort();
  const sortedSalesData = sortedDates.map((dateKey) => {
    const item = dateMap[dateKey];
    return {
      Tanggal: item.dateStr,
      formattedDate: item.displayStr,
      total_nilai: item.sum,
      MA_3: 0,
      Is_Rising: 0,
      Consecutive_Rise: 0,
    };
  });

  // 2. Count Moving Average (MA) 3 Days
  for (let i = 0; i < sortedSalesData.length; i++) {
    let sum = 0;
    let count = 0;
    // Window: [i-2, i-1, i]
    for (let offset = -2; offset <= 0; offset++) {
      const idx = i + offset;
      if (idx >= 0) {
        sum += sortedSalesData[idx].total_nilai;
        count++;
      }
    }
    sortedSalesData[i].MA_3 = count > 0 ? sum / count : 0;
  }

  // 4 & 5. Identify Is_Rising and Consecutive_Rise streaks
  let runStreak = 0;
  for (let i = 0; i < sortedSalesData.length; i++) {
    if (i === 0) {
      sortedSalesData[i].Is_Rising = 0;
    } else {
      // MA Hari Ini > MA Kemarin
      const isRising = sortedSalesData[i].MA_3 > sortedSalesData[i - 1].MA_3 ? 1 : 0;
      sortedSalesData[i].Is_Rising = isRising;
    }

    if (sortedSalesData[i].Is_Rising === 1) {
      runStreak++;
    } else {
      runStreak = 0; // Reset automatically to 0 if MA declines/plateaus
    }
    sortedSalesData[i].Consecutive_Rise = runStreak;
  }

  return {
    dailySales: sortedSalesData,
    targetLabel,
    isFallback,
  };
}

/**
 * Custom Apriori and Association Rule implementation in TypeScript (Step 6)
 * Mimics mlxtend's apriori + association_rules on pivot transaction basket
 */
export function computeMarketBasketAnalysis(
  allRows: SalesRow[],
  minSupport = 0.01,
  minLift = 1.0
): AssociationRule[] {
  // Group products by unique invoice nomor_struk
  const basketMap: { [nomor_struk: string]: Set<string> } = {};
  allRows.forEach((row) => {
    if (!basketMap[row.nomor_struk]) {
      basketMap[row.nomor_struk] = new Set<string>();
    }
    basketMap[row.nomor_struk].add(row.nama_produk);
  });

  const transactionList = Object.values(basketMap);
  const totalTransactions = transactionList.length;
  if (totalTransactions === 0) return [];

  // Count item support (frequent itemset 1)
  const itemCounts: { [item: string]: number } = {};
  transactionList.forEach((set) => {
    set.forEach((item) => {
      itemCounts[item] = (itemCounts[item] || 0) + 1;
    });
  });

  const frequentItems: string[] = [];
  const itemSupports: { [item: string]: number } = {};

  Object.keys(itemCounts).forEach((item) => {
    const support = itemCounts[item] / totalTransactions;
    if (support >= minSupport) {
      frequentItems.push(item);
      itemSupports[item] = support;
    }
  });

  // Count pairs co-occurrence support (frequent itemset 2)
  const pairCounts: { [pairKey: string]: { count: number; itemA: string; itemB: string } } = {};
  for (let i = 0; i < frequentItems.length; i++) {
    for (let j = i + 1; j < frequentItems.length; j++) {
      const itemA = frequentItems[i];
      const itemB = frequentItems[j];
      const pairKey = `${itemA}||${itemB}`;

      transactionList.forEach((set) => {
        if (set.has(itemA) && set.has(itemB)) {
          if (!pairCounts[pairKey]) {
            pairCounts[pairKey] = { count: 0, itemA, itemB };
          }
          pairCounts[pairKey].count += 1;
        }
      });
    }
  }

  const generatedRules: AssociationRule[] = [];

  Object.values(pairCounts).forEach(({ count, itemA, itemB }) => {
    const pairSupport = count / totalTransactions;
    if (pairSupport >= minSupport) {
      const suppA = itemSupports[itemA];
      const suppB = itemSupports[itemB];

      // Rule A -> B
      const confAtoB = pairSupport / suppA;
      const liftAtoB = confAtoB / suppB;
      if (liftAtoB >= minLift) {
        generatedRules.push({
          antecedents: [itemA],
          consequents: [itemB],
          invoiceCount: count,
          support: pairSupport,
          confidence: confAtoB,
          lift: liftAtoB,
        });
      }

      // Rule B -> A
      const confBtoA = pairSupport / suppB;
      const liftBtoA = confBtoA / suppA;
      if (liftBtoA >= minLift) {
        generatedRules.push({
          antecedents: [itemB],
          consequents: [itemA],
          invoiceCount: count,
          support: pairSupport,
          confidence: confBtoA,
          lift: liftBtoA,
        });
      }
    }
  });

  // Sort rules descending by Lift Score, then confidence
  return generatedRules.sort((a, b) => b.lift - a.lift || b.confidence - a.confidence);
}

/**
 * Computes general analytical numbers from daily metrics and rules
 */
export function generateAnalysisSummary(
  allRows: SalesRow[],
  dailySales: DailySalesData[],
  rules: AssociationRule[],
  targetProduct: string
): AnalysisSummary {
  const totalRevenue = allRows.reduce((sum, r) => sum + r.total_nilai, 0);
  const totalTransactions = new Set(allRows.map((r) => r.nomor_struk)).size;
  const uniqueProducts = Array.from(new Set(allRows.map((r) => r.nama_produk)));

  let rekorKenaikan = 0;
  let rekorTanggal = "-";

  dailySales.forEach((d) => {
    if (d.Consecutive_Rise > rekorKenaikan) {
      rekorKenaikan = d.Consecutive_Rise;
      rekorTanggal = d.formattedDate;
    }
  });

  return {
    rekorKenaikan,
    rekorTanggal,
    targetProduct,
    totalRevenue,
    totalTransactions,
    uniqueProducts,
    rulesCount: rules.length,
  };
}
